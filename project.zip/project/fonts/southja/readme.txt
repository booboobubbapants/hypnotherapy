Enjoy this font!

The demo font is for PERSONAL USE ONLY! but any donation are very appreciated.

Paypal account for donation:
PayPal.Me/amindesignjember


Thank you,
Best regards!
Jawan