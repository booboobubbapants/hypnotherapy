This demo font is for PERSONAL USE ONLY! 

Black Label is a clean Minimal Font  that combines simplicity and precision it works well in titles and headlines.

►►► Only the full version includes > Medium and Semibold

But any donation is very appreciated.
►►► Paypal account for donation : paypal.me/goicha

Link to purchase the full version and commercial license:
http://goicha.org/downloads/goichas-font-bundle/

Thank You